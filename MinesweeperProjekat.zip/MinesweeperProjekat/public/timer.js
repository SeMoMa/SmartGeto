
var passedTimeTag = document.getElementById("timer-value");
var downloadTimer ;
document.getElementById("gameStart").addEventListener("click", function () {
    
    var time = 1; 
    downloadTimer = setInterval(function function1() {
        passedTimeTag.innerHTML = time;
        document.getElementById("youWon").innerHTML = "";
        time += 1;

        if (time >= 12) {
            clearInterval(downloadTimer);
            document.getElementById("timer").innerHTML = "Game over!";      
        }

    }, 1000);
    console.log(timer);
});
document.getElementById("lose").addEventListener("click", function () {

    clearInterval(downloadTimer);
    document.getElementById("timer").innerHTML = "Game over!";
    document.getElementById("youWon").innerHTML = "";

});
document.getElementById("win").addEventListener("click", function () {
    clearInterval(downloadTimer);
    document.getElementById("youWon").innerHTML = "GG";

});
document.getElementById("save").addEventListener("click", function () {
 
    if( localStorage.getItem("highScore") == null)
        localStorage.setItem("highScore",    passedTimeTag.innerHTML );
    else{
        if(localStorage.getItem("highScore") < passedTimeTag.innerHTML)
            localStorage.setItem("highScore",    passedTimeTag.innerHTML );
    }
    window.location = '/highscore.html';
    //document.getElementById("saved").innerHTML = downloadTimer;
});
