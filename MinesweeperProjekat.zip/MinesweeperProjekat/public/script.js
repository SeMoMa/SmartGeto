var naslov = document.getElementById("naslov");
var sacuvajDugme = document.getElementById("saveBtn");
var prikaziDugme = document.getElementById("loadBtn");

function promena(){
    naslov.innerHTML = "Promena";
    console.log(naslov);
}

function sacuvaj(){
    var poeni = document.getElementById("poeni");
    localStorage.setItem("poeni",poeni.value);
}

function prikazi(){
    var poeni = localStorage.getItem("poeni");
    var p = document.getElementById("sacuvano");
    p.innerHTML = "Sacuvano je " + poeni;
}

prikaziDugme.addEventListener('click', prikazi);
sacuvajDugme.addEventListener('click',sacuvaj);
naslov.addEventListener('click',promena);


