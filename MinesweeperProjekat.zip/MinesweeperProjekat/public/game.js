
function createBoard(boardSize, numberOfMines) {
    const board = []
    for (let x = 0; x < boardSize; x++){
        const row = []
        for (let y = 0; y < boardSize; y++){
            const title = {
                x,
                y
            }
            row.push(title)
        }
        board.push(row)
    }
}