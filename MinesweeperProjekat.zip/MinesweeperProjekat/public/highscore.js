window.addEventListener('load', (event) => {
    document.getElementById('saved').innerHTML = localStorage.getItem('highScore');
  });